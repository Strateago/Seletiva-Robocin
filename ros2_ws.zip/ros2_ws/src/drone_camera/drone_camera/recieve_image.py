#!/usr/bin/env python3
from __future__ import print_function
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import numpy as np
from dronekit import connect, VehicleMode, LocationGlobalRelative
from pymavlink import mavutil
import time

class RecieveImage(Node):

    def __init__(self):
        super().__init__("image_reciever")
        #Faz o subscribe no tópico /camera/image_raw
        self.image_reciever_ = self.create_subscription(Image, "/camera/image_raw", self.ImageCallback, 10)

    def ImageCallback(self, msg: Image):
        Red_Higher = np.array([180, 255, 255])
        Red_Lower = np.array([170, 120, 70])
        Green_Higher = np.array([70, 255, 255])
        Green_Lower = np.array([50, 100, 100])
        Pink_Higher = np.array([170, 255, 255])
        Pink_Lower = np.array([140, 100, 100])
        Blue_Higher = np.array([130, 255, 255])
        Blue_Lower = np.array([110, 100, 100])
        global state

        def send_ned_velocity(velocity_x, velocity_y, velocity_z):
            """
            Move vehicle in direction based on specified velocity vectors.
            """
            msg = drone.message_factory.set_position_target_local_ned_encode(
                0,       # time_boot_ms (not used)
                0, 0,    # target system, target component
                mavutil.mavlink.MAV_FRAME_LOCAL_NED, # frame
                0b0000111111000111, # type_mask (only speeds enabled)
                0, 0, 0, # x, y, z positions (not used)
                velocity_x, velocity_y, velocity_z, # x, y, z velocity in m/s
                0, 0, 0, # x, y, z acceleration (not supported yet, ignored in GCS_Mavlink)
                0, 0)    # yaw, yaw_rate (not supported yet, ignored in GCS_Mavlink)
            drone.send_mavlink(msg)

        bridge = CvBridge()
        cv_image = bridge.imgmsg_to_cv2(msg, "bgr8")
        #Muda para o formato hsv
        hsv= cv2.cvtColor(cv_image, cv2.COLOR_BGR2HSV)
        #Aplica filtros para saber qual cor é
        green_filter = cv2.inRange(hsv, Green_Lower, Green_Higher)
        blue_filter = cv2.inRange(hsv, Blue_Lower, Blue_Higher)
        pink_filter = cv2.inRange(hsv, Pink_Lower, Pink_Higher)
        red_filter = cv2.inRange(hsv, Red_Lower, Red_Higher)

        #Descobre qual a cor no centro da imagem e age de acordo
        if green_filter[240][320] == 255 and state == 0:
            print("Green")
            send_ned_velocity(-1, 0, 0)
        elif blue_filter[240][320] == 255 and state <= 1:
            print("Blue");
            if state == 0:
                send_ned_velocity(1, 0, 0)
                time.sleep(1.5)
                send_ned_velocity(0, 0, 0)
                condition_yaw(90, True)
                state = 1
            send_ned_velocity(0, -1, 0)
        elif pink_filter[240][320] == 255 and state <= 2:
            print("Pink");
            if state == 1:
                send_ned_velocity(0, 1, 0)
                time.sleep(1.5)
                send_ned_velocity(0, 0, 0)
                condition_yaw(90, True)
                state = 2
            send_ned_velocity(1, 0, 0)
        elif red_filter[240][320] == 255 and state <= 3:
            print("Red");
            if state == 2:
                send_ned_velocity(-1, 0, 0)
                time.sleep(1.5)
                send_ned_velocity(0, 0, 0)
                condition_yaw(90, True)
                state = 3
            send_ned_velocity(0, 1, 0)
        elif green_filter[240][320] == 255 and state == 3:
            print("Landing")
            send_ned_velocity(0, -1, 0)
            time.sleep(1.5)
            send_ned_velocity(0, 0, 0)
            drone.mode = VehicleMode("LAND")

def condition_yaw(heading, relative):
            if relative:
                is_relative=1 #yaw relative to direction of travel
            else:
                is_relative=0 #yaw is an absolute angle
            # create the CONDITION_YAW command using command_long_encode()
            msg = drone.message_factory.command_long_encode(
                0, 0,    # target system, target component
                mavutil.mavlink.MAV_CMD_CONDITION_YAW, #command
                0, #confirmation
                heading,    # param 1, yaw in degrees
                0,          # param 2, yaw speed deg/s
                1,          # param 3, direction -1 ccw, 1 cw
                is_relative, # param 4, relative offset 1, absolute angle 0
                0, 0, 0)    # param 5 ~ 7 not used
            # send command to vehicle
            drone.send_mavlink(msg)
            time.sleep(5)

def main(args=None):
    ConnectionString = '127.0.0.1:14550'
    print("Connecting on ", ConnectionString)
    global drone
    drone = connect(ConnectionString, wait_ready=True)
    global state
    state = 0

    #Arm drone
    while not drone.is_armable:
        print("Waiting initializing")
        time.sleep(1)

    print("Arming Drone")
    drone.mode = VehicleMode("GUIDED")
    drone.armed = True
    while not drone.armed:
        print("Waiting to arm")
        time.sleep(1)

    #Taking Off
    print("Taking Off")
    drone.simple_takeoff(1)
    while True:
        if drone.location.global_relative_frame.alt >= 0.9:
            print("Ready to move")
            break
        time.sleep(1)

    LAT_Init = -35.3632216
    LON_Init = 149.1652885

    #Moving
    print("Moving")
    location1 = LocationGlobalRelative(LAT_Init, LON_Init, 1)
    drone.simple_goto(location1, airspeed = 2)
    time.sleep(5)
    condition_yaw(180, False)

    #Cria Node
    rclpy.init(args=args)
    node = RecieveImage()
    rclpy.spin(node)
    rclpy.shutdown()
